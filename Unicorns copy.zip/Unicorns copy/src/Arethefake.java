
import java.text.NumberFormat;
import java.util.*;

public class Arethefake {

	//instance variables
	private String name;
	private int accountNum;
	private double balance;
	
	//the Account constructor

	public Arethefake(String name, int accountNum, double balance) {
	
		this.name = name;
		this.accountNum = accountNum;
		this.balance = balance;
	}
	//method to deposit a specified amount into the account
	public void deposit(double amount) {
		balance = balance + amount;
	}
	//method to withdraw a specified amount form the account
	public void withdraw (double amount, double fee) {
		balance = balance - amount - fee;
	}
//getting method to return balance
	public double getBalance(){
		return balance;
	}
	//toString method that returns the accounts information
	public String toString(){
		 String result = "";
		 NumberFormat fmt = NumberFormat.getCurrencyInstance();
		 result = "\nName: " + name + "\nAccount Number: " + accountNum + "\nBalance: " + fmt.format(balance);
		 return result;
		 }
	
}
