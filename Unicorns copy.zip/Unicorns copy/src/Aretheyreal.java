
import java.util.*;

public class Aretheyreal {

	public static void main(String[] args) {
		// Variables used to create account
		String name;
		int accountNum;
		double amount;
		final int MAX = 999999;
		
	//Scanner for user input, Random for random number/
	Scanner keyboard = new Scanner(System.in);
	Random rand = new Random();
	
	//random number genereated for account number. Generates a number for 0 up to max
	accountNum = rand.nextInt(MAX);
	
	//get user input to create account
	System.out.println("Enter full name: ");
	name = keyboard.nextLine();
	System.out.println("Enter amount to depost: ");
	amount = keyboard.nextDouble();
	
	//instantiate new object, acct1, with user's values
	Arethefake acct1 = new Arethefake(name, accountNum, amount);
	
	//display account information using toString method
	System.out.println(acct1.toString());
	
		

	}

}
